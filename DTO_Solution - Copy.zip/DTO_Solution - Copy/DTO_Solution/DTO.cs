﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.Infrastructure;
using System.IO;

namespace DTO_Solution
{  
    public class Employee
    {
        [Display(Name = "Employee Name")]
        [Key]
        public string  EmployeeName { get; set; }
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true, NullDisplayText = "No Date")]
        [Display(Name = "Birth Date")]
        public DateTime BirthDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:C}")]      
        [Display(Name = "Salary")]
        public decimal Salary { get; set; }
        [Display(Name = "Date Hired")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true, NullDisplayText = "No Date")]
        public DateTime DateHired { get; set; }
        [Display(Name = "Valid Records")]
        public string IsValid { get; set; }
    }

    public class LoadEmployees
    {
        //public string FileLocation { get; set; }
        public List<Employee> EmployeeRecords = new List<Employee>();

        //public LoadEmployees()
        //{

        //}

        //public LoadEmployees(string filePath)
        //{
        //    FileLocation = filePath;
        //}
       
        
        //public List<Employee> GetEmployees()
        //{
        //    return EmployeeRecords;
        //}

        public List<Employee> GetEmployees(string filePath)
        {
            return parseFile(filePath);
        }

        private List<Employee> parseFile(string fileName)
        {
            List<Employee> Employees = new List<Employee>();
            string[] stringSeparators = new string[] { "\r\n" };

            try
            {
                var csvTable = File.ReadAllText(fileName).Split(stringSeparators, StringSplitOptions.None);
                //var secondSplit = from line in myList
                //                  select line.Split(',').ToList();

                var lRows = csvTable.Skip(1).ToList();
                foreach (var csvRow in lRows)
                {
                    if (!string.IsNullOrEmpty(csvRow))
                    {
                        string[] csvFields = csvRow.Split(',');

                        Employee e = parseRecord(csvFields);

                        Employees.Add(e);
                    }

                }
                return Employees;
            }
            catch
            {
                return null;
            }
        }   
    
        private Employee parseRecord(string[] csvLine)
        {
            if (csvLine.Length > 0)
            {
                Employee tempEmployee = new Employee();
                string isValid = "Valid";

                int fieldCount = csvLine.Length;

                if (fieldCount < 3)
                {
                    isValid = "Invalid";
                }

                for (int i = 0; i < fieldCount; i++)
                {
                    string cleanField = string.Empty;
                    DateTime dt = new DateTime();

                    cleanField = csvLine[i].ToString().Replace("\"", "").Replace("?", "").Replace("“", "").Replace("”", "").Replace("�", "");

                    switch (i)
                    {
                        case 0:

                            if (!string.IsNullOrEmpty(cleanField))
                            {
                                tempEmployee.EmployeeName = cleanField;
                            }
                            else
                            {
                                isValid = "Invalid";
                            }
                            break;
                        case 1:
                            if (!string.IsNullOrEmpty(cleanField) && DateTime.TryParse(cleanField, out dt))
                            {
                                tempEmployee.BirthDate = dt;
                            }
                            else
                            {
                                isValid = "Invalid";
                            }
                            break;
                        case 2:
                            decimal dc = new decimal();
                            decimal.TryParse(cleanField, out dc);

                            if (!string.IsNullOrEmpty(cleanField) && dc > 0)
                            {
                                tempEmployee.Salary = dc;
                            }
                            else
                            {
                                isValid = "Invalid";
                            }
                            break;
                        case 3:

                            if (!string.IsNullOrEmpty(cleanField) && DateTime.TryParse(cleanField, out dt))
                            {
                                tempEmployee.DateHired = dt;
                            }
                            else
                            {
                                isValid = "Invalid";
                            }
                            break;
                    }
                }

                tempEmployee.IsValid = isValid;

                return tempEmployee;
            }

            return null;
        }
    }

    public class EmployeesContext : DbContext
    {
        public DbSet<Employee> EmployeeList { get; set; }
    }

    public class MVCEmployeesInitializer : DropCreateDatabaseIfModelChanges<EmployeesContext>
    {

        protected override void Seed(EmployeesContext context)
        {
            try
            {
                LoadEmployees le = new LoadEmployees();
                //List<Employee> Employees = new List<Employee>();
                var Employees = le.GetEmployees(@"C:\Employees.csv");
                Employees.ForEach(s => context.EmployeeList.Add(s));

                context.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
    }   
}
