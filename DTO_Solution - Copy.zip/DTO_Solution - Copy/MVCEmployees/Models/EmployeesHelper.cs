﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.Infrastructure;
using System.IO;
using DTO_Solution;



namespace MVCEmployees.Models
{
    public class EmployeesHelper
    {
    }

    //MVC Binding

    //public class Employee
    //{
    //    [Display(Name = "Employee Name")]
    //    [Key]
    //    public string EmployeeName { get; set; }
    //    [Display(Name = "Birth Date")]
    //    public DateTime BirthDate { get; set; }
    //    [Display(Name = "Salary")]
    //    public decimal Salary { get; set; }
    //    [Display(Name = "Date Hired")]
    //    public DateTime DateHired { get; set; }
    //    [Display(Name = "Valid Records")]
    //    public string IsValid { get; set; }
    //}

    //public class EmployeesContext : DbContext
    //{
    //    public DbSet<Employee> EmployeeList { get; set; }
    //}

    //public class MVCEmployeesInitializer : DropCreateDatabaseIfModelChanges<EmployeesContext>
    //{

    //    protected override void Seed(EmployeesContext context)
    //    { 
    //        try
    //        {
                
    //            LoadEmployees le = new LoadEmployees();
    //            //List<Employee> Employees = new List<Employee>();

    //            var Employees =le.GetEmployees(@"C:\Employees.csv");
    //            Employees.ForEach(s => context.EmployeeList.Add(s));
                
    //            context.SaveChanges();
    //        }
    //        catch
    //        {
    //            throw;
    //        }          
    //    }
    //}    
}