﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_Solution;
using System.IO;

namespace ConsoleEmployees
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exitProgram = false;
            string fileName = string.Empty;
            List<Employee> Employees = new List<Employee>();

            do
            {
                Console.Clear();
                Console.Write("Enter File Name or 0 to exit: ");
                fileName = Console.ReadLine();

                if (fileName != "0")
                {
                    if (!string.IsNullOrEmpty(fileName) && File.Exists(fileName))
                    {
                        LoadEmployees le = new LoadEmployees();
                        Employees = le.GetEmployees(fileName);

                        if (Employees != null)
                        {
                            foreach (var e in Employees)
                            {
                                string sDisplay = e.EmployeeName + "\t" + e.BirthDate.ToShortDateString() + "\t" + e.Salary.ToString() + "\t" + e.DateHired.ToShortDateString() + "\t" + e.IsValid + "\r\n";
                                Console.Write(sDisplay);
                            }

                            //Console.Write("\r\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid File Name");
                    }
                    Console.ReadLine();
                }
                else
                {
                    exitProgram = true;
                }
            } while (exitProgram == false);

        }
    }
}
